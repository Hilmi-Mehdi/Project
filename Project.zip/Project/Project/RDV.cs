﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class RDV : Form
    {
        public RDV()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void RDV_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cabinetMedicalDataSet3.RDV' table. You can move, or remove it, as needed.
            this.rDVTableAdapter.Fill(this.cabinetMedicalDataSet3.RDV);
            // TODO: This line of code loads data into the 'cabinetMedicalDataSet2.RDV' table. You can move, or remove it, as needed.


        }
    }
}
