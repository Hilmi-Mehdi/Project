﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class MenuMedecin : Form
    {
        public MenuMedecin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Patient p = new Patient();
            p.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RDV p = new RDV();
            p.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Medic m = new Medic();
            m.Show();
        }
    }
}
