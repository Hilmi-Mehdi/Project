﻿
namespace Project
{
    partial class Medic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Medic));
            this.codeapciDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numtelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sexpatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datenpatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prepatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nompatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numpatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.patientTableAdapter = new Project.CabinetMedicalDataSetTableAdapters.PatientTableAdapter();
            this.patientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cabinetMedicalDataSet = new Project.CabinetMedicalDataSet();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Addresse = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.addrspatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cabinetMedicalDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // codeapciDataGridViewTextBoxColumn
            // 
            this.codeapciDataGridViewTextBoxColumn.DataPropertyName = "Code_apci";
            this.codeapciDataGridViewTextBoxColumn.HeaderText = "Code_apci";
            this.codeapciDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.codeapciDataGridViewTextBoxColumn.Name = "codeapciDataGridViewTextBoxColumn";
            // 
            // numtelDataGridViewTextBoxColumn
            // 
            this.numtelDataGridViewTextBoxColumn.DataPropertyName = "Num_tel";
            this.numtelDataGridViewTextBoxColumn.HeaderText = "Num_tel";
            this.numtelDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numtelDataGridViewTextBoxColumn.Name = "numtelDataGridViewTextBoxColumn";
            // 
            // sexpatDataGridViewTextBoxColumn
            // 
            this.sexpatDataGridViewTextBoxColumn.DataPropertyName = "Sex_pat";
            this.sexpatDataGridViewTextBoxColumn.HeaderText = "Sex_pat";
            this.sexpatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.sexpatDataGridViewTextBoxColumn.Name = "sexpatDataGridViewTextBoxColumn";
            // 
            // datenpatDataGridViewTextBoxColumn
            // 
            this.datenpatDataGridViewTextBoxColumn.DataPropertyName = "Date_n_pat";
            this.datenpatDataGridViewTextBoxColumn.HeaderText = "Date_n_pat";
            this.datenpatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.datenpatDataGridViewTextBoxColumn.Name = "datenpatDataGridViewTextBoxColumn";
            // 
            // prepatDataGridViewTextBoxColumn
            // 
            this.prepatDataGridViewTextBoxColumn.DataPropertyName = "Pre_pat";
            this.prepatDataGridViewTextBoxColumn.HeaderText = "Pre_pat";
            this.prepatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.prepatDataGridViewTextBoxColumn.Name = "prepatDataGridViewTextBoxColumn";
            // 
            // nompatDataGridViewTextBoxColumn
            // 
            this.nompatDataGridViewTextBoxColumn.DataPropertyName = "Nom_pat";
            this.nompatDataGridViewTextBoxColumn.HeaderText = "Nom_pat";
            this.nompatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nompatDataGridViewTextBoxColumn.Name = "nompatDataGridViewTextBoxColumn";
            // 
            // numpatDataGridViewTextBoxColumn
            // 
            this.numpatDataGridViewTextBoxColumn.DataPropertyName = "Num_pat";
            this.numpatDataGridViewTextBoxColumn.HeaderText = "Num_pat";
            this.numpatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numpatDataGridViewTextBoxColumn.Name = "numpatDataGridViewTextBoxColumn";
            this.numpatDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // patientTableAdapter
            // 
            this.patientTableAdapter.ClearBeforeFill = true;
            // 
            // patientBindingSource
            // 
            this.patientBindingSource.DataMember = "Patient";
            this.patientBindingSource.DataSource = this.cabinetMedicalDataSet;
            // 
            // cabinetMedicalDataSet
            // 
            this.cabinetMedicalDataSet.DataSetName = "CabinetMedicalDataSet";
            this.cabinetMedicalDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Poppins", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(126, 339);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 34);
            this.label8.TabIndex = 46;
            this.label8.Text = "Forme";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Poppins", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(126, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 34);
            this.label7.TabIndex = 45;
            this.label7.Text = "Nom";
            // 
            // Addresse
            // 
            this.Addresse.AutoSize = true;
            this.Addresse.Font = new System.Drawing.Font("Poppins", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresse.Location = new System.Drawing.Point(126, 261);
            this.Addresse.Name = "Addresse";
            this.Addresse.Size = new System.Drawing.Size(88, 34);
            this.Addresse.TabIndex = 41;
            this.Addresse.Text = "Dosage";
            this.Addresse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Poppins", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(126, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 34);
            this.label1.TabIndex = 40;
            this.label1.Text = "Famille";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(59, 425);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(266, 43);
            this.button4.TabIndex = 39;
            this.button4.Text = "Nouveau";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(380, 425);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(266, 43);
            this.button3.TabIndex = 38;
            this.button3.Text = "Ajouter";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(59, 520);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(266, 43);
            this.button2.TabIndex = 37;
            this.button2.Text = "Modifier";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(380, 520);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(266, 43);
            this.button1.TabIndex = 36;
            this.button1.Text = "Supprimer";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numpatDataGridViewTextBoxColumn,
            this.nompatDataGridViewTextBoxColumn,
            this.prepatDataGridViewTextBoxColumn,
            this.datenpatDataGridViewTextBoxColumn,
            this.sexpatDataGridViewTextBoxColumn,
            this.numtelDataGridViewTextBoxColumn,
            this.addrspatDataGridViewTextBoxColumn,
            this.codeapciDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.patientBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(59, 597);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(587, 235);
            this.dataGridView1.TabIndex = 35;
            // 
            // addrspatDataGridViewTextBoxColumn
            // 
            this.addrspatDataGridViewTextBoxColumn.DataPropertyName = "Addrs_pat";
            this.addrspatDataGridViewTextBoxColumn.HeaderText = "Addrs_pat";
            this.addrspatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.addrspatDataGridViewTextBoxColumn.Name = "addrspatDataGridViewTextBoxColumn";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(380, 339);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(227, 35);
            this.textBox5.TabIndex = 34;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(380, 261);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(227, 35);
            this.textBox4.TabIndex = 33;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(380, 182);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(227, 35);
            this.textBox2.TabIndex = 30;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Poppins", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(380, 112);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(227, 35);
            this.textBox1.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Poppins", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(510, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(375, 60);
            this.label3.TabIndex = 28;
            this.label3.Text = "Gestion des patients";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(745, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(615, 867);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // Medic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 953);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Addresse);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Medic";
            this.Text = "Medic";
            ((System.ComponentModel.ISupportInitialize)(this.patientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cabinetMedicalDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn codeapciDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numtelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sexpatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datenpatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prepatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nompatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numpatDataGridViewTextBoxColumn;
        private CabinetMedicalDataSetTableAdapters.PatientTableAdapter patientTableAdapter;
        private System.Windows.Forms.BindingSource patientBindingSource;
        private CabinetMedicalDataSet cabinetMedicalDataSet;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label Addresse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn addrspatDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}